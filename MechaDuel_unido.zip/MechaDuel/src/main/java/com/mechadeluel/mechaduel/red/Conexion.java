package com.mechadeluel.mechaduel.red;

import java.net.Socket;
import java.io.*;
import java.util.concurrent.CountDownLatch;

public class Conexion {

    private Socket entrada;
    private Socket salida;

    private BufferedReader receptor;
    private PrintWriter emisor;

    private final CountDownLatch conexionLista =
            new CountDownLatch(1);

    private volatile Exception errorEntrada;

    public void iniciar(int miPuerto, String ipRival,
                        int puertoRival) throws Exception {

        // 1. Crear nuestro servidor
        Servidor servidor = new Servidor(miPuerto);

        // 2. Esperar la conexion entrante en otro hilo
        Thread hiloServidor = new Thread(() -> {

            try {

                entrada = servidor.aceptarConexion();

                receptor = new BufferedReader(
                        new InputStreamReader(
                                entrada.getInputStream()
                        )
                );

                System.out.println("Conexion entrante lista");

            } catch (Exception e) {

                errorEntrada = e;

            } finally {

                conexionLista.countDown();
            }

        });

        hiloServidor.start();

        // 3. Conectarnos al servidor del rival
        Cliente cliente = new Cliente(ipRival, puertoRival);

        salida = cliente.getSocket();

        emisor = new PrintWriter(
                salida.getOutputStream(), true
        );

        // 4. Esperar hasta recibir la conexion entrante
        conexionLista.await();

        if (errorEntrada != null) {
            throw errorEntrada;
        }

        System.out.println("Ambas conexiones estan listas");
    }

    // Enviar mensajes al rival
    public void enviar(String mensaje) {

        emisor.println(mensaje);

        if (emisor.checkError()) {
            throw new IllegalStateException(
                    "No se pudo enviar el mensaje"
            );
        }
    }

    // Recibir mensajes del rival
    public String recibir() throws IOException {

        return receptor.readLine();
    }
}