package com.mechadeluel.mechaduel.interfaz;

import com.mechadeluel.mechaduel.modelo.MechaTanque;
import com.mechadeluel.mechaduel.modelo.MechaAtacante;
import com.mechadeluel.mechaduel.modelo.MechaVeloz;
import com.mechadeluel.mechaduel.modelo.Robot;
import com.mechadeluel.mechaduel.red.Conexion;
import com.mechadeluel.mechaduel.archivo.ArchivosJuego;
import java.io.IOException;

import java.util.Scanner;

public class ConsolaJuego {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Sé Bienvenido a MECHA DUEL ===");
        System.out.println("Entrando a etapa de preparación...");

        System.out.print("Ingrese su puerto: ");
        int miPuerto = scanner.nextInt();

        scanner.nextLine();

        System.out.print("Ingrese la IP del rival: ");
        String ipRival = scanner.nextLine();

        System.out.print("Ingrese el puerto del rival: ");
        int puertoRival = scanner.nextInt();

        Conexion conexion = new Conexion();

        try {
            conexion.iniciar(
                    miPuerto,
                    ipRival,
                    puertoRival
            );

            System.out.println("¡Conexión establecida!");


            System.out.println("Selecciona el arquetipo que deseas para tu mecha: ");
        System.out.println("1. Mecha Tanque (Especializado en resistencia y blindaje)");
        System.out.println("2. Mecha Veloz (Especializado en agilidad y turnos)");
        System.out.println("3. Mecha Atacante (Especializado en ofensiva y fuerza)");
        System.out.print("Elige una opción (1, 2 o 3): ");
        int opcionArquetipo = scanner.nextInt();

        System.out.println("Asigna tus puntos para el combate (la suma de todos debe ser igual a 200");

        int atk, def, nrg, spd;
        while(true) {
            System.out.print("Ingresa el valor del ataque (ATK): ");
            atk = scanner.nextInt();
            System.out.print("Ingresa el valor de la defensa (DEF): ");
            def = scanner.nextInt();
            System.out.print("Ingresa el valor de la velocidad (SPD): ");
            spd = scanner.nextInt();
            System.out.print("Ingresa el valor de la energía (NRG): ");
            nrg = scanner.nextInt();

            if((atk + def + spd + nrg) == 200){
                break;
            }
            System.out.println("Ocurrió un error... la suma total debe ser 200. Intente otra vez. Use calculadora de ser necesario.\n");
        }

        Robot RobotTransmilenio=null; // supuse que este era el robot propio
        Robot RobotEnemigo=null;// agrege el robot enemigo

        if(opcionArquetipo == 1) {
            RobotTransmilenio = new MechaTanque(atk, def, spd, nrg);
            System.out.println("\n¡Has ensamblado en un Mecha de tipo tanque!");
        }
        if(opcionArquetipo == 2) {
            RobotTransmilenio = new MechaVeloz(atk, def, spd, nrg);
            System.out.println("\n¡Has ensamblado en un Mecha de tipo veloz!");
        }
        if(opcionArquetipo == 3) {
            RobotTransmilenio = new MechaAtacante(atk, def, spd, nrg);
            System.out.println("\n¡Has ensamblado en un Mecha de tipo ataque!");
        }

        System.out.println("¡Ensamblaste tu robot con éxito! Tus HP iniciales: " + RobotTransmilenio.getHp());

        String mensajeHabilidad = RobotTransmilenio.ejecutarHabilidadEspecial();
        System.out.println("Habilidad del sistema: " + mensajeHabilidad);

            ArchivosJuego archivos = new ArchivosJuego();

            try {
                archivos.guardarRobot(RobotTransmilenio);
                System.out.println("¡Robot guardado correctamente!");

            } catch (IOException e) {
                System.out.println("Error al guardar el robot.");
                e.printStackTrace();
            }

        //aqui va el menu de combate y las opciones para la estrategia
        boolean siguienteGolpe=true;
        int energia= RobotTransmilenio.getNrg(); // energia actual
        int hpActual = RobotTransmilenio.getHp();  // vida propia actual a partir de la maxima
        int hpEActual = RobotEnemigo.getHp(); // vida enemiga actual a partir de la maxima
        // teoricamente estos se podrian reemplzar para que el otro sistema sea el que lo calcule enviando solo el daño pero eso depende de la comunicacion
        // dodge funciona de forma similar
        int velocidad=0;
        do {

            if((velocidad+RobotTransmilenio.getSpd())>=100) {
                int mov = 0;// que movimiento se va a usar
                mov = scanner.nextInt();
                int cont = 0;// veces que se uso dodge
                System.out.println("ingrese la accion que quiera hacer\n 1 ATTACK \n 2 ESPECIAL \n 3 DODGE \n 4 HEAL \n 5 CHARGE ");

                switch (mov) {
                    case 1:

                        hpEActual = (hpEActual - Attack(RobotTransmilenio, RobotEnemigo));

                        break;
                    case 2:

                        hpEActual = (hpEActual - Especial(RobotTransmilenio, RobotEnemigo));

                        break;
                    case 3:

                        siguienteGolpe = Dodge(cont); // determina si el siguiente golpe hace daño, depende de la comunicacion para activarse

                        break;
                    case 4:

                        hpActual += 10;

                        break;
                    case 5:

                        energia += 10;

                        break;
                }
            }
            velocidad+= RobotTransmilenio.getSpd();

        }while (hpActual !=0);
        } catch (Exception e) {

            System.out.println("Error de conexión");
            e.printStackTrace();

        }
    }

    public static int Attack(Robot RobotA, Robot RobotB){
        int dmg=0;// el daño que va a recibir el robot enemigo
        // atk normal, formula larga
        return  dmg=(int)Math.round(Math.pow(RobotB.getAtk() ,2)/(RobotA.getDef()+RobotB.getAtk()));//robot B esta atacando a A

    }
    public static int Especial(Robot RobotA, Robot RobotB){
        int dmg=0;// el daño que va a recibir el robot enemigo
        // atk especial, formula mas larga
        return dmg =(int)Math.round(Math.pow(RobotB.getAtk()+(RobotB.getNrg()*0.5), 2 ) /(RobotB.getAtk()+(RobotB.getNrg()*0.5)+RobotA.getDef()));// B ataca a A
        // cuando se haga la comunicacion la energia debe de cambiarse por la energia actual del enemigo a comparacion de la base que se usa justo ahora
    }
    public static boolean Dodge(int cont){

        // esquivar
        if(cont==0) {
            if ((1 + (int) Math.random() * ((100 - 1) + 1)) % 2 == 0) {
                System.out.println("Dodged");
                cont++;
                return true;
            } else {
                System.out.println("Hit");
                cont++;
                return false;
            }

        }else if(cont==1) {
            if ((1 + (int) Math.random() * ((100 - 1) + 1))  <= 75) {
                System.out.println("Dodged");
                cont--;
                return true;
            } else {
                System.out.println("Hit");
                cont--;
                return false;
            }

        }
        return false;
    }
    /*public static int heal(int hp){
        return RobotA.getHp()+10;
    } //estas se volvieron inutiles pero aun estan por si acaso
    public static int charge(Robot RobotA){
        return RobotA.getNrg()+10;
    }
    */
    // esto va al inicio del turno
    public int estado(Robot RobotA, Robot RobotB){
        if( RobotA.getEfectosEstado().equals("quemadura")){
            return RobotB.getHp()-3; // este es para el enemigo, el que pierde la vida,
        }else if(RobotA.getEfectosEstado().equals("regeneracion")){
            return RobotA.getHp()+3;
        }else if(RobotA.getEfectosEstado().equals("nucleo activo")){ // si acaso cambiar como se escribe este si acaso
            return RobotA.getNrg()+2;
        }
        return 0;
    }

}
