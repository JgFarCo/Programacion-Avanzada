package com.mechadeluel.mechaduel.red;

import java.net.Socket;
import java.io.IOException;

public class Cliente {

    private Socket socket;

    public Cliente(String ip, int puerto) throws IOException {

        socket = new Socket(ip, puerto);

        System.out.println("Conexion saliente establecida");
    }

    public Socket getSocket() {
        return socket;
    }
}
