package com.mechadeluel.mechaduel.red;

import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;

public class Servidor {

    private ServerSocket servidor;

    public Servidor(int puerto) throws IOException {

        servidor = new ServerSocket(puerto);

        System.out.println("Servidor esperando conexion...");
    }

    public Socket aceptarConexion() throws IOException {
        return servidor.accept();
    }
}