package com.mechadeluel.mechaduel.archivo;

import com.mechadeluel.mechaduel.modelo.Robot;
import java.io.*;

public class ArchivosJuego {

    // Guardar el robot
    public void guardarRobot(Robot robot) throws IOException {

        ObjectOutputStream salida = new ObjectOutputStream(
                new FileOutputStream("robots.bin")
        );

        salida.writeObject(robot);
        salida.close();
    }

    // Recuperar el robot
    public Robot cargarRobot() throws IOException, ClassNotFoundException {

        ObjectInputStream entrada = new ObjectInputStream(
                new FileInputStream("robots.bin")
        );


        Robot robot = (Robot) entrada.readObject();
        entrada.close();

        return robot;
    }

    // Guardar un movimiento
    public void guardarMovimiento(String movimiento) throws IOException {

        FileWriter archivo = new FileWriter("movimientos.txt", true);
        BufferedWriter escritor = new BufferedWriter(archivo);

        escritor.write(movimiento);
        escritor.newLine();

        escritor.close();
    }

    // Vacia movimientos.txt para que solo contenga los movimientos de la partida actual
    public void reiniciarMovimientos() throws IOException {
        new FileWriter("movimientos.txt", false).close();
    }
}
