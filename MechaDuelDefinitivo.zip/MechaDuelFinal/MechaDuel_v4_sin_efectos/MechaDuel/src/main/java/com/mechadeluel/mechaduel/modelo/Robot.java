package com.mechadeluel.mechaduel.modelo;


import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public abstract class Robot implements Serializable {
    protected int hp;
    protected int atk;
    protected int def;
    protected int spd;
    protected int nrg;
    protected String efectosEstado; //esto aca es para colocarle quemadura, regeneración, etc

    public Robot(int atk, int def, int spd, int nrg, String efectosEstado) {
        if((atk + def + spd + nrg) != 200){
            throw new IllegalArgumentException("La suma de las estadísticas debe dar 200");
        }
        this.hp = 100;
        this.atk = atk;
        this.def = def;
        this.nrg = nrg;
        this.spd = spd;
        this.efectosEstado = efectosEstado;
    }

    // Constructor sin validar la suma: solo para reconstruir al rival con las stats finales
    // recibidas por red (ya incluyen el bono de su arquetipo, por eso pueden sumar mas de 200)
    protected Robot(int atk, int def, int spd, int nrg,String efectosEstado, boolean sinValidar){
        this.hp = 100;
        this.atk = atk;
        this.def = def;
        this.nrg = nrg;
        this.spd = spd;
        this.efectosEstado = efectosEstado;
    }

    public abstract String ejecutarHabilidadEspecial();
    public abstract void pasiva(Robot rival);

    public int getHp() { return hp; }
    public void setHp(int hp) { this.hp = Math.max(0, hp); }

    public int getAtk() {return atk; }
    public int getDef() {return def; }
    public int getSpd() {return spd; }
    public void setSpd(int spd) { this.spd = spd; }
    public int getNrg() {return nrg; }
    public void setNrg(int nrg) { this.nrg = nrg;}

    public String getEfectosEstado() {return efectosEstado; }
}
