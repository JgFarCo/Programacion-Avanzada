package com.mechadeluel.mechaduel.modelo;

public class MechaVeloz extends Robot {

    public MechaVeloz(int atk, int def, int spd, int nrg, String efectosEstado) {
            super(atk, def, spd, nrg, efectosEstado);
    }

    @Override
    public String ejecutarHabilidadEspecial() {
        this.spd += 10;
        return "¡Arquetipo de velocidad activado! La velocidad ha aumentado";
    }
    @Override
    public void pasiva(Robot rival) {
        this.nrg += 2;
    }

}