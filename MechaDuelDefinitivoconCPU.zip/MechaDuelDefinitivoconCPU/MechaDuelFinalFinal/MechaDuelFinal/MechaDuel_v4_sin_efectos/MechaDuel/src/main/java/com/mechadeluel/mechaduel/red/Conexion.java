package com.mechadeluel.mechaduel.red;

import java.net.Socket;
import java.io.*;
import java.util.concurrent.CountDownLatch;

public class Conexion {

    private Socket entrada;
    private Socket salida;

    private BufferedReader receptor;
    private PrintWriter emisor;

    private final CountDownLatch conexionLista =
            new CountDownLatch(1);

    private volatile Exception errorEntrada;

    public void iniciar(int miPuerto, String ipRival,
                        int puertoRival) throws Exception {

        
        Servidor servidor = new Servidor(miPuerto);

        
        Thread hiloServidor = new Thread(() -> {

            try {

                entrada = servidor.aceptarConexion();

                receptor = new BufferedReader(
                        new InputStreamReader(
                                entrada.getInputStream()
                        )
                );

                System.out.println("Conexion entrante lista");

            } catch (Exception e) {

                errorEntrada = e;

            } finally {

                conexionLista.countDown();
            }

        });

        hiloServidor.start();

        
        Cliente cliente = new Cliente(ipRival, puertoRival);

        salida = cliente.getSocket();

        emisor = new PrintWriter(
                salida.getOutputStream(), true
        );

        
        conexionLista.await();

        if (errorEntrada != null) {
            throw errorEntrada;
        }

        System.out.println("Ambas conexiones estan listas");
    }

    
    public void enviar(String mensaje) {

        emisor.println(mensaje);

        if (emisor.checkError()) {
            throw new IllegalStateException(
                    "No se pudo enviar el mensaje"
            );
        }
    }

    
    public String recibir() throws IOException {

        return receptor.readLine();
    }
}