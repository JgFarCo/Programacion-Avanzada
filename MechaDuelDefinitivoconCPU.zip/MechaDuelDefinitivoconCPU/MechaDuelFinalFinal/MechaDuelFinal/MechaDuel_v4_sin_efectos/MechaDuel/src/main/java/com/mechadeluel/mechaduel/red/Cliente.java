package com.mechadeluel.mechaduel.red;

import java.net.Socket;
import java.io.IOException;

public class Cliente {

    private Socket socket;

    public Cliente(String ip, int puerto) throws IOException {
        IOException ultimo = null;
        for (int i = 0; i < 60; i++) {                 
            try {
                socket = new Socket(ip, puerto);
                System.out.println("Conexion saliente establecida");
                return;
            } catch (IOException e) {
                ultimo = e;
                System.out.println("Esperando al rival...");
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new IOException(ie);
                }
            }
        }
        throw ultimo;
    }

    public Socket getSocket() {
        return socket;
    }
}
