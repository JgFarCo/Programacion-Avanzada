package com.mechadeluel.mechaduel.modelo;

public class MechaTanque extends Robot {

    public MechaTanque(int atk, int def, int spd, int nrg, String efectosEstado) {
        super(atk, def, spd, nrg, efectosEstado);
    }

    @Override
    public String ejecutarHabilidadEspecial() {
        
        this.def += 10; 
        return "¡Arquetipo tanque activado! La defensa ha aumentado.";
    }
    @Override
    public void pasiva(Robot rival) {
        this.hp+=3;
    }
}
