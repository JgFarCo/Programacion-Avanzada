package com.mechadeluel.mechaduel.interfaz;

import com.mechadeluel.mechaduel.archivo.ArchivosJuego;
import com.mechadeluel.mechaduel.modelo.MechaAtacante;
import com.mechadeluel.mechaduel.modelo.MechaRival;
import com.mechadeluel.mechaduel.modelo.MechaTanque;
import com.mechadeluel.mechaduel.modelo.MechaVeloz;
import com.mechadeluel.mechaduel.modelo.Robot;
import com.mechadeluel.mechaduel.red.Conexion;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;

public class MechaDuelGUI extends Application {

    private static final String[] MOVIMIENTOS = {"ATTACK", "SPECIAL", "DODGE", "HEAL", "CHARGE"};
    private static final String ARCHIVO_ESTRATEGIA = "estrategia.txt";

    private Conexion conexion;
    private final ArchivosJuego archivos = new ArchivosJuego();
    private final Random azar = new Random();

    private boolean modoCPU = false;

    private Robot yo;
    private Robot rival;
    private int miPuerto = 5000;
    private int puertoRival = 5001;
    private int opcionArquetipo;
    private int atkBase;
    private int defBase;
    private int spdBase;
    private int nrgBase;
    private int esquivasPendientes = 0;
    private int esquivasCPU = 0;

    private List<String> estrategia = null;
    private int indiceEstrategia = 0;
    private boolean usarEstrategiaAutomatica = false;
    private boolean grabarEstrategia = false;

    private Stage stage;
    private volatile String movimientoElegidoUsuario;
    private CountDownLatch esperaTurnoUsuario;

    private Label lblEstadoPropio;
    private Label lblEstadoRival;
    private Label lblTurnoActual;
    private TextArea txtLogCombate;
    private ListView<String> listaMovsPropios;
    private ListView<String> listaMovsRival;
    private HBox panelBotonesAccion;

    @Override
    public void start(Stage primaryStage) {
        this.stage = primaryStage;
        primaryStage.setTitle("Mecha Duel");
        mostrarPantallaConexion();
        primaryStage.show();
    }

    
    private void mostrarPantallaConexion() {
        Label lblTitulo = new Label("MECHA DUEL - Modo de Juego y Conexión");
        lblTitulo.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        ToggleGroup grupoModo = new ToggleGroup();
        RadioButton rbRed = new RadioButton("Multijugador por Red (Conexión Remota ON)");
        rbRed.setToggleGroup(grupoModo);
        rbRed.setSelected(true);

        RadioButton rbCPU = new RadioButton("Jugar vs CPU con Decisiones de Estrategia (Local - Red OFF)");
        rbCPU.setToggleGroup(grupoModo);

        Label lblInfoCPU = new Label("CPU tomará decisiones tácticas según HP, NRG y estadísticas del combate.");
        lblInfoCPU.setStyle("-fx-text-fill: #2e7d32;");
        lblInfoCPU.setDisable(true);

        TextField txtMiPuerto = new TextField();
        txtMiPuerto.setPromptText("Tu puerto (ej. 5000)");

        TextField txtIpRival = new TextField();
        txtIpRival.setPromptText("IP del rival (ej. 127.0.0.1 o IPv4 del rival)");

        TextField txtPuertoRival = new TextField();
        txtPuertoRival.setPromptText("Puerto del rival (ej. 5001)");

        Label lblRedInfo = new Label("Parámetros de red (solo para modo multijugador):");
        lblRedInfo.setStyle("-fx-text-fill: #555555;");

        grupoModo.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            boolean esCPU = (newVal == rbCPU);
            lblInfoCPU.setDisable(!esCPU);
            txtMiPuerto.setDisable(esCPU);
            txtIpRival.setDisable(esCPU);
            txtPuertoRival.setDisable(esCPU);
            lblRedInfo.setText(esCPU
                    ? "Conexión Remota OFF: partida local contra CPU."
                    : "Parámetros de red (solo para modo multijugador):");
        });

        Button btnContinuar = new Button("Continuar al Ensamble");
        btnContinuar.setMaxWidth(Double.MAX_VALUE);
        Label lblEstado = new Label();

        btnContinuar.setOnAction(e -> {
            try {
                if (rbCPU.isSelected()) {
                    modoCPU = true;
                    conexion = null;
                    miPuerto = 5000;
                    puertoRival = 5001;
                    mostrarPantallaEnsamble();
                    return;
                }

                modoCPU = false;
                miPuerto = validarPuerto(txtMiPuerto.getText());
                String ip = txtIpRival.getText().trim();
                if (ip.isEmpty()) {
                    throw new IllegalArgumentException("Ingresa la IP del rival.");
                }
                puertoRival = validarPuerto(txtPuertoRival.getText());

                btnContinuar.setDisable(true);
                lblEstado.setStyle("-fx-text-fill: #1565c0;");
                lblEstado.setText("Conectando con el rival... (esperando conexión)");

                new Thread(() -> {
                    try {
                        conexion = new Conexion();
                        conexion.iniciar(miPuerto, ip, puertoRival);
                        Platform.runLater(this::mostrarPantallaEnsamble);
                    } catch (Exception ex) {
                        String mensajeError = ex.getMessage() != null ? ex.getMessage() : ex.getClass().getSimpleName();
                        Platform.runLater(() -> {
                            btnContinuar.setDisable(false);
                            lblEstado.setStyle("-fx-text-fill: #c62828;");
                            lblEstado.setText("Error de conexión: " + mensajeError);
                        });
                    }
                }).start();

            } catch (Exception ex) {
                lblEstado.setStyle("-fx-text-fill: #c62828;");
                lblEstado.setText(ex.getMessage());
            }
        });

        VBox root = new VBox(10,
                lblTitulo,
                rbRed,
                rbCPU,
                lblInfoCPU,
                lblRedInfo,
                new Label("Tu Puerto:"), txtMiPuerto,
                new Label("IP del Rival:"), txtIpRival,
                new Label("Puerto del Rival:"), txtPuertoRival,
                btnContinuar,
                lblEstado);
        root.setPadding(new Insets(18));
        stage.setScene(new Scene(root, 445, 450));
    }

    private int validarPuerto(String texto) {
        try {
            int p = Integer.parseInt(texto.trim());
            if (p < 1 || p > 65535) {
                throw new IllegalArgumentException("El puerto debe estar entre 1 y 65535.");
            }
            return p;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Ingresa un número de puerto válido.");
        }
    }

    
    private void mostrarPantallaEnsamble() {
        String subtitulo = modoCPU
                ? "Ensamble de Robot - vs CPU con Estrategia (Red OFF)"
                : "Ensamble de Robot - Multijugador";
        Label lblTitulo = new Label(subtitulo);
        lblTitulo.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        ComboBox<String> cmbArquetipo = new ComboBox<>();
        cmbArquetipo.getItems().addAll(
                "1. Mecha Tanque (Defensa + Regeneración)",
                "2. Mecha Veloz (Velocidad + Núcleo Activo)",
                "3. Mecha Atacante (Ataque + Quemadura)"
        );
        cmbArquetipo.getSelectionModel().selectFirst();
        cmbArquetipo.setMaxWidth(Double.MAX_VALUE);

        TextField txtAtk = new TextField();
        txtAtk.setPromptText("Ataque (ATK)");
        TextField txtDef = new TextField();
        txtDef.setPromptText("Defensa (DEF)");
        TextField txtSpd = new TextField();
        txtSpd.setPromptText("Velocidad (SPD)");
        TextField txtNrg = new TextField();
        txtNrg.setPromptText("Energía (NRG)");

        Button btnEnsamblar = new Button("Ensamblar e Iniciar Combate");
        btnEnsamblar.setMaxWidth(Double.MAX_VALUE);
        Label lblMensaje = new Label();

        btnEnsamblar.setOnAction(e -> {
            try {
                atkBase = Integer.parseInt(txtAtk.getText().trim());
                defBase = Integer.parseInt(txtDef.getText().trim());
                spdBase = Integer.parseInt(txtSpd.getText().trim());
                nrgBase = Integer.parseInt(txtNrg.getText().trim());

                if (atkBase < 0 || defBase < 0 || spdBase < 0 || nrgBase < 0) {
                    throw new IllegalArgumentException("Los valores no pueden ser negativos.");
                }

                opcionArquetipo = cmbArquetipo.getSelectionModel().getSelectedIndex() + 1;
                yo = crearRobot(opcionArquetipo, atkBase, defBase, spdBase, nrgBase);
                String habilidad = yo.ejecutarHabilidadEspecial();

                btnEnsamblar.setDisable(true);
                lblMensaje.setStyle("-fx-text-fill: #2e7d32;");
                lblMensaje.setText(habilidad + (modoCPU
                        ? "\nPreparando oponente CPU local..."
                        : "\nEsperando datos del rival..."));

                new Thread(() -> {
                    try {
                        if (modoCPU) {
                            rival = crearRobotCPU();
                            rival.ejecutarHabilidadEspecial();
                        } else {
                            conexion.enviar("HP:" + yo.getHp()
                                    + ",ATK:" + yo.getAtk()
                                    + ",DEF:" + yo.getDef()
                                    + ",SPD:" + yo.getSpd()
                                    + ",NRG:" + yo.getNrg()
                                    + ",EFF:" + yo.getEfectosEstado());

                            String recibido = conexion.recibir();
                            if (recibido == null) {
                                throw new IOException("El rival cerró la conexión.");
                            }

                            String[] p = recibido.split("[,:]");
                            rival = new MechaRival(
                                    Integer.parseInt(p[3].trim()),
                                    Integer.parseInt(p[5].trim()),
                                    Integer.parseInt(p[7].trim()),
                                    Integer.parseInt(p[9].trim()),
                                    p[11].trim()
                            );
                        }

                        estrategia = cargarEstrategia();
                        configurarModoEstrategiaEnGUI();

                        Platform.runLater(this::mostrarPantallaCombate);
                        new Thread(this::ejecutarCombate).start();

                    } catch (Exception ex) {
                        String mensajeError = ex.getMessage() != null ? ex.getMessage() : ex.getClass().getSimpleName();
                        Platform.runLater(() -> {
                            btnEnsamblar.setDisable(false);
                            lblMensaje.setStyle("-fx-text-fill: #c62828;");
                            lblMensaje.setText("Error en preparación: " + mensajeError);
                        });
                    }
                }).start();

            } catch (NumberFormatException ex) {
                lblMensaje.setStyle("-fx-text-fill: #c62828;");
                lblMensaje.setText("Error: Solo puedes ingresar números enteros.");
            } catch (IllegalArgumentException ex) {
                lblMensaje.setStyle("-fx-text-fill: #c62828;");
                lblMensaje.setText(ex.getMessage());
            }
        });

        VBox root = new VBox(10, lblTitulo, cmbArquetipo, txtAtk, txtDef, txtSpd, txtNrg, btnEnsamblar, lblMensaje);
        root.setPadding(new Insets(20));
        stage.setScene(new Scene(root, 445, 445));
    }

    private Robot crearRobotCPU() {
        int variante = azar.nextInt(3);
        if (variante == 0) {
            return new MechaTanque(45, 65, 50, 40, "Regeneracion");
        }
        if (variante == 1) {
            return new MechaVeloz(55, 35, 70, 40, "Nucleo Activo");
        }
        return new MechaAtacante(65, 35, 50, 50, "Quemadura");
    }

    private void configurarModoEstrategiaEnGUI() throws InterruptedException {
        usarEstrategiaAutomatica = false;
        grabarEstrategia = false;

        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean elegirAuto = new AtomicBoolean(false);
        AtomicBoolean elegirGrabar = new AtomicBoolean(false);

        Platform.runLater(() -> {
            try {
                if (estrategia != null && !estrategia.isEmpty()) {
                    Alert alertaAuto = new Alert(Alert.AlertType.CONFIRMATION);
                    alertaAuto.setTitle("Modo de Combate");
                    alertaAuto.setHeaderText("Se encontró estrategia.txt con " + estrategia.size() + " movimientos.");
                    alertaAuto.setContentText("¿Deseas jugar en MODO ESTRATEGIA AUTOMÁTICA?\n(Elige Cancelar para jugar MANUALMENTE)");
                    Optional<ButtonType> resAuto = alertaAuto.showAndWait();
                    if (resAuto.isPresent() && resAuto.get() == ButtonType.OK) {
                        elegirAuto.set(true);
                        return;
                    }
                }

                Alert alertaGrabar = new Alert(Alert.AlertType.CONFIRMATION);
                alertaGrabar.setTitle("Modo Manual");
                alertaGrabar.setHeaderText("Jugarás en MODO MANUAL.");
                alertaGrabar.setContentText("¿Deseas grabar los movimientos de esta partida en estrategia.txt?");
                Optional<ButtonType> resGrabar = alertaGrabar.showAndWait();
                elegirGrabar.set(resGrabar.isPresent() && resGrabar.get() == ButtonType.OK);
            } finally {
                latch.countDown();
            }
        });

        latch.await();
        usarEstrategiaAutomatica = elegirAuto.get();
        grabarEstrategia = !usarEstrategiaAutomatica && elegirGrabar.get();
    }

    
    private void mostrarPantallaCombate() {
        lblEstadoPropio = new Label();
        lblEstadoPropio.setStyle("-fx-font-weight: bold; -fx-text-fill: #1b5e20;");

        lblEstadoRival = new Label();
        lblEstadoRival.setStyle("-fx-font-weight: bold; -fx-text-fill: #b71c1c;");

        lblTurnoActual = new Label("Preparando combate...");
        lblTurnoActual.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        txtLogCombate = new TextArea();
        txtLogCombate.setEditable(false);
        txtLogCombate.setPrefHeight(170);

        listaMovsPropios = new ListView<>();
        listaMovsRival = new ListView<>();

        VBox colPropios = new VBox(5, new Label("Tus Movimientos"), listaMovsPropios);
        VBox colRival = new VBox(5, new Label(modoCPU ? "Movimientos de la CPU" : "Movimientos del Rival"), listaMovsRival);
        HBox.setHgrow(colPropios, Priority.ALWAYS);
        HBox.setHgrow(colRival, Priority.ALWAYS);
        HBox listas = new HBox(12, colPropios, colRival);
        listas.setPrefHeight(180);

        panelBotonesAccion = new HBox(8);
        for (String mov : MOVIMIENTOS) {
            final String accionBoton = mov;
            Button btn = new Button(accionBoton);
            btn.setMaxWidth(Double.MAX_VALUE);
            HBox.setHgrow(btn, Priority.ALWAYS);
            btn.setOnAction(e -> {
                if (esperaTurnoUsuario != null) {
                    movimientoElegidoUsuario = accionBoton;
                    panelBotonesAccion.setDisable(true);
                    esperaTurnoUsuario.countDown();
                }
            });
            panelBotonesAccion.getChildren().add(btn);
        }
        panelBotonesAccion.setDisable(true);

        VBox root = new VBox(10, lblEstadoPropio, lblEstadoRival, lblTurnoActual,
                panelBotonesAccion, new Label("Bitácora del Combate:"), txtLogCombate, listas);
        root.setPadding(new Insets(15));
        stage.setScene(new Scene(root, 710, 585));
        actualizarBarrasEstado();
    }

    private void actualizarBarrasEstado() {
        final String textoPropio = yo != null
                ? String.format("TÚ -> HP: %d | ATK: %d | DEF: %d | SPD: %d | NRG: %d | Efecto: %s",
                yo.getHp(), yo.getAtk(), yo.getDef(), yo.getSpd(), yo.getNrg(), yo.getEfectosEstado())
                : "";
        final String etiquetaRival = modoCPU ? "CPU" : "RIVAL";
        final String textoRival = rival != null
                ? String.format("%s -> HP: %d | ATK: %d | DEF: %d | SPD: %d | NRG: %d | Efecto: %s",
                etiquetaRival, rival.getHp(), rival.getAtk(), rival.getDef(), rival.getSpd(), rival.getNrg(), rival.getEfectosEstado())
                : "";

        Platform.runLater(() -> {
            if (lblEstadoPropio != null) {
                lblEstadoPropio.setText(textoPropio);
            }
            if (lblEstadoRival != null) {
                lblEstadoRival.setText(textoRival);
            }
        });
    }

    private void log(final String texto) {
        Platform.runLater(() -> {
            if (txtLogCombate != null) {
                txtLogCombate.appendText(texto + "\n");
            }
        });
    }

    private void ejecutarCombate() {
        try {
            archivos.reiniciarMovimientos();
            boolean soyPrimero = decidirPrimero(miPuerto, puertoRival);
            log("=== ¡COMIENZA EL COMBATE! ===");
            if (modoCPU) {
                log("Modo vs CPU local activo (Conexión Remota OFF) | CPU usando decisiones de estrategia.");
            }
            log(usarEstrategiaAutomatica
                    ? "Tu modo: estrategia automática (" + estrategia.size() + " movimientos cíclicos)."
                    : "Tu modo: manual" + (grabarEstrategia ? " (grabando en estrategia.txt)." : " (sin grabar en estrategia.txt)."));

            if (yo.getSpd() + rival.getSpd() == 0) {
                log("Ningún robot tiene velocidad: nadie podrá actuar.");
                return;
            }

            int miCont = 0;
            int rivCont = 0;
            while (yo.getHp() > 0 && rival.getHp() > 0) {
                miCont += yo.getSpd();
                rivCont += rival.getSpd();
                boolean miTurno = miCont >= 100;
                boolean suTurno = rivCont >= 100;

                if (miTurno && suTurno) {
                    if (soyPrimero) {
                        miCont -= 100;
                        turnoPropio();
                        yo.pasiva(rival);
                        actualizarBarrasEstado();
                        if (yo.getHp() > 0 && rival.getHp() > 0) {
                            rivCont -= 100;
                            turnoRival();
                            rival.pasiva(yo);
                            actualizarBarrasEstado();
                        }
                    } else {
                        rivCont -= 100;
                        turnoRival();
                        rival.pasiva(yo);
                        actualizarBarrasEstado();
                        if (yo.getHp() > 0 && rival.getHp() > 0) {
                            miCont -= 100;
                            turnoPropio();
                            yo.pasiva(rival);
                            actualizarBarrasEstado();
                        }
                    }
                } else if (miTurno) {
                    miCont -= 100;
                    turnoPropio();
                    yo.pasiva(rival);
                    actualizarBarrasEstado();
                } else if (suTurno) {
                    rivCont -= 100;
                    turnoRival();
                    rival.pasiva(yo);
                    actualizarBarrasEstado();
                }
            }

            final String resultado = yo.getHp() > 0
                    ? "¡GANASTE! Tu HP final: " + yo.getHp()
                    : (modoCPU ? "LA CPU GANÓ. HP final de la CPU: " : "PERDISTE. HP final del rival: ") + rival.getHp();
            log("\n=== FIN DE LA PARTIDA ===\n" + resultado);
            Platform.runLater(() -> {
                lblTurnoActual.setText(resultado);
                preguntarGuardadoGUI(resultado);
            });

        } catch (Exception ex) {
            final String err = ex.getMessage() != null ? ex.getMessage() : ex.getClass().getSimpleName();
            log("Error durante el combate: " + err);
            Platform.runLater(() -> lblTurnoActual.setText("Error: " + err));
        }
    }

    private void turnoPropio() throws Exception {
        Platform.runLater(() -> lblTurnoActual.setText("TU TURNO: Elige una acción"));
        final String mov = elegirMovimiento();

        if (!modoCPU) {
            conexion.enviar(mov);
        }
        archivos.guardarMovimiento(mov);
        Platform.runLater(() -> listaMovsPropios.getItems().add(mov));

        if (!mov.equals("DODGE")) {
            esquivasPendientes = 0;
        }

        switch (mov) {
            case "ATTACK":
            case "SPECIAL": {
                boolean especial = mov.equals("SPECIAL");
                int dmg = calcularDanio(yo, rival, especial);
                String resp;
                if (modoCPU) {
                    resp = resolverEsquivaCPU() ? "DODGE" : "HIT";
                } else {
                    resp = conexion.recibir();
                    if (resp == null) {
                        throw new IOException("El rival cerró la conexión.");
                    }
                }
                if (especial) {
                    yo.setNrg(0);
                }

                if (resp.trim().equalsIgnoreCase("HIT")) {
                    rival.setHp(rival.getHp() - dmg);
                    log("Tú usaste " + mov + " -> HIT: " + (modoCPU ? "la CPU" : "el rival") + " pierde " + dmg + " HP.");
                } else {
                    log("Tú usaste " + mov + " -> DODGE: ¡" + (modoCPU ? "la CPU" : "el rival") + " esquivó!");
                }
                break;
            }
            case "DODGE":
                esquivasPendientes = Math.min(2, esquivasPendientes + 1);
                log("Te preparas para esquivar (" + (esquivasPendientes == 1 ? "50%" : "75%") + ").");
                break;
            case "HEAL":
                yo.setHp(Math.min(100, yo.getHp() + 10));
                log("Recuperas 10 HP.");
                break;
            case "CHARGE":
                yo.setNrg(yo.getNrg() + 10);
                log("Cargas 10 de energía.");
                break;
        }
        actualizarBarrasEstado();
    }

    private void turnoRival() throws IOException {
        final String nombreRival = modoCPU ? "LA CPU" : "DEL RIVAL";
        Platform.runLater(() -> {
            panelBotonesAccion.setDisable(true);
            lblTurnoActual.setText("TURNO " + nombreRival + ": Decidiendo estrategia...");
        });

        final String accionRival;
        if (modoCPU) {
            try {
                Thread.sleep(450);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            accionRival = decidirMovimientoCPU();
        } else {
            String msg = conexion.recibir();
            if (msg == null) {
                throw new IOException("El rival cerró la conexión.");
            }
            accionRival = msg.trim().toUpperCase();
        }

        archivos.guardarMovimiento((modoCPU ? "CPU: " : "RIVAL: ") + accionRival);
        Platform.runLater(() -> listaMovsRival.getItems().add(accionRival));

        switch (accionRival) {
            case "ATTACK":
            case "SPECIAL": {
                boolean especial = accionRival.equals("SPECIAL");
                int dmg = calcularDanio(rival, yo, especial);
                int prob = (esquivasPendientes == 0 ? 0 : (esquivasPendientes == 1 ? 50 : 75));
                esquivasPendientes = 0;
                boolean esquive = azar.nextInt(100) < prob;
                if (especial) {
                    rival.setNrg(0);
                }

                if (esquive) {
                    if (!modoCPU) {
                        conexion.enviar("DODGE");
                    }
                    log((modoCPU ? "La CPU" : "El rival") + " usó " + accionRival + " -> ¡Lo esquivaste!");
                } else {
                    if (!modoCPU) {
                        conexion.enviar("HIT");
                    }
                    yo.setHp(yo.getHp() - dmg);
                    log((modoCPU ? "La CPU" : "El rival") + " usó " + accionRival + " -> HIT: pierdes " + dmg + " HP.");
                }
                break;
            }
            case "DODGE":
                log((modoCPU ? "La CPU" : "El rival") + " se prepara para esquivar.");
                esquivasCPU = Math.min(2, esquivasCPU + 1);
                break;
            case "HEAL":
                rival.setHp(Math.min(100, rival.getHp() + 10));
                log((modoCPU ? "La CPU" : "El rival") + " recupera 10 HP.");
                break;
            case "CHARGE":
                rival.setNrg(rival.getNrg() + 10);
                log((modoCPU ? "La CPU" : "El rival") + " carga energía.");
                break;
            default:
                log("Instrucción desconocida del rival: " + accionRival);
                break;
        }
        actualizarBarrasEstado();
    }

    private boolean resolverEsquivaCPU() {
        int prob = (esquivasCPU == 0) ? 0 : (esquivasCPU == 1 ? 50 : 75);
        esquivasCPU = 0;
        return azar.nextInt(100) < prob;
    }

    private String decidirMovimientoCPU() {
        if (rival.getHp() <= 30 && rival.getHp() < 100 && azar.nextInt(100) < 65) {
            return "HEAL";
        }
        if (rival.getNrg() >= 30 && yo.getHp() <= 45) {
            return "SPECIAL";
        }
        if (rival.getNrg() < 20 && azar.nextInt(100) < 45) {
            return "CHARGE";
        }
        if (yo.getAtk() > rival.getDef() + 15 && azar.nextInt(100) < 35) {
            return "DODGE";
        }
        return "ATTACK";
    }

    private String elegirMovimiento() throws Exception {
        if (usarEstrategiaAutomatica && estrategia != null && !estrategia.isEmpty()) {
            String mov = estrategia.get(indiceEstrategia % estrategia.size());
            indiceEstrategia++;
            log("Estrategia automática: " + mov);
            Thread.sleep(600);
            return mov;
        }

        esperaTurnoUsuario = new CountDownLatch(1);
        Platform.runLater(() -> panelBotonesAccion.setDisable(false));
        esperaTurnoUsuario.await();

        String mov = movimientoElegidoUsuario;
        if (grabarEstrategia) {
            Files.write(Paths.get(ARCHIVO_ESTRATEGIA),
                    (mov + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        }
        return mov;
    }

    private void preguntarGuardadoGUI(String resultado) {
        Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
        alerta.setTitle("Fin de la Partida");
        alerta.setHeaderText(resultado);
        alerta.setContentText("¿Deseas guardar la configuración inicial de tu robot en robots.bin?");

        Optional<ButtonType> resp = alerta.showAndWait();
        if (resp.isPresent() && resp.get() == ButtonType.OK) {
            try {
                archivos.guardarRobot(crearRobot(opcionArquetipo, atkBase, defBase, spdBase, nrgBase));
                log("¡Robot guardado correctamente en robots.bin!");
            } catch (IOException e) {
                log("Error al guardar el robot: " + e.getMessage());
            }
        }
    }

    private Robot crearRobot(int opcion, int atk, int def, int spd, int nrg) {
        if (opcion == 1) {
            return new MechaTanque(atk, def, spd, nrg, "Regeneracion");
        }
        if (opcion == 2) {
            return new MechaVeloz(atk, def, spd, nrg, "Nucleo Activo");
        }
        return new MechaAtacante(atk, def, spd, nrg, "Quemadura");
    }

    private boolean decidirPrimero(int miPuerto, int puertoRival) {
        int c = Integer.compare(yo.getSpd(), rival.getSpd());
        if (c == 0) {
            c = Integer.compare(yo.getAtk(), rival.getAtk());
        }
        if (c == 0) {
            c = Integer.compare(yo.getDef(), rival.getDef());
        }
        if (c == 0) {
            c = Integer.compare(yo.getNrg(), rival.getNrg());
        }
        if (c == 0) {
            c = Integer.compare(miPuerto, puertoRival);
        }
        return c > 0;
    }

    private int calcularDanio(Robot atacante, Robot defensor, boolean especial) {
        double atk = atacante.getAtk() + (especial ? 0.5 * atacante.getNrg() : 0);
        return (int) Math.round((atk * atk) / (atk + defensor.getDef()));
    }

    private List<String> cargarEstrategia() throws IOException {
        Path ruta = Paths.get(ARCHIVO_ESTRATEGIA);
        if (!Files.exists(ruta)) {
            return null;
        }
        List<String> validos = new ArrayList<>();
        for (String linea : Files.readAllLines(ruta, StandardCharsets.UTF_8)) {
            String mov = linea.trim().toUpperCase();
            if (!mov.isEmpty() && Arrays.asList(MOVIMIENTOS).contains(mov)) {
                validos.add(mov);
            }
        }
        return validos.isEmpty() ? null : validos;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
