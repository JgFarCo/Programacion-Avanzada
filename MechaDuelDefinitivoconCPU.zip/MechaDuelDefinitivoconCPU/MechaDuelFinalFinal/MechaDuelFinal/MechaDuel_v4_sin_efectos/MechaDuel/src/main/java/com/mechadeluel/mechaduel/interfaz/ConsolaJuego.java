package com.mechadeluel.mechaduel.interfaz;

import com.mechadeluel.mechaduel.modelo.MechaTanque;
import com.mechadeluel.mechaduel.modelo.MechaAtacante;
import com.mechadeluel.mechaduel.modelo.MechaVeloz;
import com.mechadeluel.mechaduel.modelo.MechaRival;
import com.mechadeluel.mechaduel.modelo.Robot;
import com.mechadeluel.mechaduel.red.Conexion;
import com.mechadeluel.mechaduel.archivo.ArchivosJuego;
import javafx.application.Application;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ConsolaJuego {

    private static final Scanner scanner = new Scanner(System.in);
    private static final Random azar = new Random();
    private static final String[] MOVIMIENTOS = {"ATTACK", "SPECIAL", "DODGE", "HEAL", "CHARGE"};
    private static final String[] NOMBRES_ARQUETIPO = {"tanque", "veloz", "ataque"};

    private static Conexion conexion;
    private static final ArchivosJuego archivos = new ArchivosJuego();

    private static Robot yo;      
    private static Robot rival;   

    
    private static int esquivasPendientes = 0;
    private static final String ARCHIVO_ESTRATEGIA = "estrategia.txt";
    private static List<String> estrategia = null;   
    private static int indiceEstrategia = 0;
    private static boolean grabarEstrategia = false;   

    public static void main(String[] args) {
        System.out.println("=== Sé Bienvenido a MECHA DUEL ===");
        System.out.println("Entrando a etapa de preparación...");

        int miPuerto = leerEntero("Ingrese su puerto: ", 1, 65535);
        scanner.nextLine();   

        System.out.print("Ingrese la IP del rival: ");
        String ipRival = scanner.nextLine();

        int puertoRival = leerEntero("Ingrese el puerto del rival: ", 1, 65535);

        conexion = new Conexion();

        try {
            conexion.iniciar(miPuerto, ipRival, puertoRival);
            System.out.println("¡Conexión establecida!");

            
            System.out.println("Selecciona el arquetipo que deseas para tu mecha: ");
            System.out.println("1. Mecha Tanque (Especializado en resistencia y blindaje)");
            System.out.println("2. Mecha Veloz (Especializado en agilidad y turnos)");
            System.out.println("3. Mecha Atacante (Especializado en ofensiva y fuerza)");

            int opcionArquetipo = leerEntero("Elige una opción (1, 2 o 3): ", 1, 3);

            System.out.println("Asigna tus puntos para el combate (la suma de todos debe ser igual a 200)");

            int atk, def, nrg, spd;
            while (true) {
                atk = leerEntero("Ingresa el valor del ataque (ATK): ", 0, 200);
                def = leerEntero("Ingresa el valor de la defensa (DEF): ", 0, 200);
                spd = leerEntero("Ingresa el valor de la velocidad (SPD): ", 0, 200);
                nrg = leerEntero("Ingresa el valor de la energía (NRG): ", 0, 200);

                if ((atk + def + spd + nrg) == 200) {
                    break;
                }
                System.out.println("Ocurrió un error... la suma total debe ser 200. Intente otra vez. Use calculadora de ser necesario.\n");
            }

            yo = crearRobot(opcionArquetipo, atk, def, spd, nrg);
            System.out.println("\n¡Has ensamblado un Mecha de tipo " + NOMBRES_ARQUETIPO[opcionArquetipo - 1] + "!");

            System.out.println("¡Ensamblaste tu robot con éxito! Tus HP iniciales: " + yo.getHp());

            String mensajeHabilidad = yo.ejecutarHabilidadEspecial();
            System.out.println("Habilidad del sistema: " + mensajeHabilidad);

            
            conexion.enviar("HP:" + yo.getHp()
                    + ",ATK:" + yo.getAtk()
                    + ",DEF:" + yo.getDef()
                    + ",SPD:" + yo.getSpd()
                    + ",NRG:" + yo.getNrg()
                    + ",EFF:" + yo.getEfectosEstado());

            String recibido = conexion.recibir();
            if (recibido == null) {
                throw new IOException("El rival cerró la conexión");
            }
            String[] p = recibido.split("[,:]");
            
            rival = new MechaRival(
                    Integer.parseInt(p[3].trim()),
                    Integer.parseInt(p[5].trim()),
                    Integer.parseInt(p[7].trim()),
                    Integer.parseInt(p[9].trim()),
                    p[11].trim());
            System.out.println("Rival listo -> ATK:" + rival.getAtk() + " DEF:" + rival.getDef()
                    + " SPD:" + rival.getSpd() + " NRG:" + rival.getNrg() + " HP:" + rival.getHp());

            List<String> cargada = cargarEstrategia();   
            if (cargada != null) {
                int modo = leerEntero("Modo de combate: 1 = Manual, 2 = Automático (estrategia.txt): ", 1, 2);
                estrategia = (modo == 2) ? cargada : null;
            } else {
                estrategia = null;
                System.out.println("No hay estrategia.txt válida: modo manual.");
            }
            grabarEstrategia = (cargada == null);
            System.out.println(estrategia != null
                    ? "Modo automático: " + estrategia.size() + " movimientos (se repiten en ciclo)."
                    : "Modo manual.");
            combatir(decidirPrimero(miPuerto, puertoRival));

            
            preguntarGuardado(opcionArquetipo, atk, def, spd, nrg);

        } catch (Exception e) {
            System.out.println("Error de conexión");
            e.printStackTrace();
        }
    }

    
    
    private static boolean decidirPrimero(int miPuerto, int puertoRival) {
        int c = Integer.compare(yo.getSpd(), rival.getSpd());
        if (c == 0) c = Integer.compare(yo.getAtk(), rival.getAtk());
        if (c == 0) c = Integer.compare(yo.getDef(), rival.getDef());
        if (c == 0) c = Integer.compare(yo.getNrg(), rival.getNrg());
        if (c == 0) c = Integer.compare(miPuerto, puertoRival);
        return c > 0;
    }

    private static boolean hayVivos() {
        return yo.getHp() > 0 && rival.getHp() > 0;
    }

    private static void combatir(boolean soyPrimero) throws IOException {
        System.out.println("\n=== ¡COMIENZA EL COMBATE! ===");
        archivos.reiniciarMovimientos();   

        if(MonitorCombateGUI.getInstancia() == null) {
            new Thread(() -> Application.launch(MonitorCombateGUI.class)).start();
            try {
                MonitorCombateGUI.esperarListo();
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }

        if (yo.getSpd() + rival.getSpd() == 0) {
            System.out.println("Ningún robot tiene velocidad: nadie podrá actuar.");
            return;
        }

        int miCont = 0;
        int rivCont = 0;

        while (hayVivos()) {
            miCont += yo.getSpd();
            rivCont += rival.getSpd();

            boolean miTurno = miCont >= 100;
            boolean suTurno = rivCont >= 100;

            if (miTurno && suTurno) {
                if (soyPrimero) {
                    miCont -= 100;
                    turnoPropio();
                    yo.pasiva(rival);
                    if (hayVivos()) {
                        rivCont -= 100;
                        turnoRival();
                        rival.pasiva(yo);
                    }
                } else {
                    rivCont -= 100;
                    turnoRival();
                    rival.pasiva(yo);
                    if (hayVivos()) {
                        miCont -= 100;
                        turnoPropio();
                        yo.pasiva(rival);
                    }
                }
            } else if (miTurno) {
                miCont -= 100;
                turnoPropio();
                yo.pasiva(rival);
            } else if (suTurno) {
                rivCont -= 100;
                turnoRival();
                rival.pasiva(yo);
            }
        }

        System.out.println("\n=== FIN DE LA PARTIDA ===");
        if (yo.getHp() > 0) {
            System.out.println("¡GANASTE! Tu HP final: " + yo.getHp());
        } else {
            System.out.println("Perdiste. HP final del rival: " + rival.getHp());
        }
    }

    
    private static void turnoPropio() throws IOException {
        System.out.println("\n--- TU TURNO --- (Tú: HP " + yo.getHp() + " NRG " + yo.getNrg()
                + " | Rival: HP " + rival.getHp() + " NRG " + rival.getNrg() + ") ---");

        String mov = elegirMovimiento();
        conexion.enviar(mov);
        archivos.guardarMovimiento(mov);

        if(MonitorCombateGUI.getInstancia() != null) {
            MonitorCombateGUI.getInstancia().registrarMovimientoPropio(mov);
        }

        if (!mov.equals("DODGE")) {
            esquivasPendientes = 0;
        }

        switch (mov) {
            case "ATTACK":
            case "SPECIAL": {
                boolean especial = mov.equals("SPECIAL");
                int dmg = calcularDanio(yo, rival, especial);

                String respuesta = conexion.recibir();
                if (respuesta == null) {
                    throw new IOException("El rival cerró la conexión");
                }
                if (especial) {
                    yo.setNrg(0);
                }

                if (respuesta.trim().equalsIgnoreCase("HIT")) {
                    rival.setHp(rival.getHp() - dmg);
                    System.out.println(mov + " -> HIT: el rival pierde " + dmg + " HP (le quedan " + rival.getHp() + ")");
                } else {
                    System.out.println(mov + " -> DODGE: ¡el rival esquivó!");
                }
                break;
            }
            case "DODGE":
                esquivasPendientes = Math.min(2, esquivasPendientes + 1);
                System.out.println("Te preparas para esquivar (" + (esquivasPendientes == 1 ? "50%" : "75%") + ").");
                break;
            case "HEAL":
                yo.setHp(Math.min(100, yo.getHp() + 10));
                System.out.println("Recuperas 10 HP. HP: " + yo.getHp());
                break;
            case "CHARGE":
                yo.setNrg(yo.getNrg() + 10);
                System.out.println("Cargas 10 de energía. NRG: " + yo.getNrg());
                break;
        }
    }

    
    private static void turnoRival() throws IOException {
        System.out.println("\n--- TURNO DEL RIVAL --- esperando su movimiento...");

        String msg = conexion.recibir();
        if (msg == null) {
            throw new IOException("El rival cerró la conexión");
        }
        msg = msg.trim().toUpperCase();

        if(MonitorCombateGUI.getInstancia() != null) {
            MonitorCombateGUI.getInstancia().registrarMovimientoRival(msg);
        }

        switch (msg) {
            case "ATTACK":
            case "SPECIAL": {
                boolean especial = msg.equals("SPECIAL");
                int dmg = calcularDanio(rival, yo, especial);

                
                int prob = (esquivasPendientes == 0) ? 0 : (esquivasPendientes == 1 ? 50 : 75);
                esquivasPendientes = 0;
                boolean esquive = azar.nextInt(100) < prob;

                if (especial) {
                    rival.setNrg(0);
                }

                if (esquive) {
                    conexion.enviar("DODGE");
                    System.out.println("El rival usó " + msg + " -> ¡lo esquivaste!");
                } else {
                    conexion.enviar("HIT");
                    yo.setHp(yo.getHp() - dmg);
                    System.out.println("El rival usó " + msg + " -> HIT: pierdes " + dmg + " HP (te quedan " + yo.getHp() + ")");
                }
                break;
            }
            case "DODGE":
                System.out.println("El rival se prepara para esquivar.");
                break;
            case "HEAL":
                rival.setHp(Math.min(100, rival.getHp() + 10));
                System.out.println("El rival recupera 10 HP. HP rival: " + rival.getHp());
                break;
            case "CHARGE":
                rival.setNrg(rival.getNrg() + 10);
                System.out.println("El rival carga energía. NRG rival: " + rival.getNrg());
                break;
            default:
                System.out.println("Instrucción desconocida del rival: " + msg);
        }
    }

    
    private static Robot crearRobot(int opcion, int atk, int def, int spd, int nrg) {
        if (opcion == 1) {
            return new MechaTanque(atk, def, spd, nrg, "Regeneracion");
        }
        if (opcion == 2) {
            return new MechaVeloz(atk, def, spd, nrg, "Nucleo Activo");
        }
        return new MechaAtacante(atk, def, spd, nrg, "Quemadura");
    }

    
    private static int leerEntero(String mensaje, int min, int max) {
        while (true) {
            System.out.print(mensaje);
            String texto = scanner.next().trim();
            try {
                int valor = Integer.parseInt(texto);
                if (valor >= min && valor <= max) {
                    return valor;
                }
                System.out.println("El valor debe estar entre " + min + " y " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Debes ingresar un número entero.");
            }
        }
    }

    
    private static void preguntarGuardado(int opcion, int atk, int def, int spd, int nrg) {
        System.out.print("\n¿Quieres guardar la configuración de tu robot en robots.bin? (s/n): ");
        String respuesta = scanner.next().trim().toLowerCase();
        if (respuesta.startsWith("s")) {
            try {
                archivos.guardarRobot(crearRobot(opcion, atk, def, spd, nrg));
                System.out.println("¡Robot guardado en robots.bin!");
            } catch (IOException e) {
                System.out.println("Error al guardar el robot.");
                e.printStackTrace();
            }
        }
    }

    
    private static int calcularDanio(Robot atacante, Robot defensor, boolean especial) {
        double atk = atacante.getAtk() + (especial ? 0.5 * atacante.getNrg() : 0);
        return (int) Math.round((atk * atk) / (atk + defensor.getDef()));
    }

    private static int leerMovimiento() {
        while (true) {
            System.out.println("Ingresa la acción que quieras hacer:\n 1 ATTACK\n 2 SPECIAL\n 3 DODGE\n 4 HEAL\n 5 CHARGE");
            if (scanner.hasNextInt()) {
                int op = scanner.nextInt();
                if (op >= 1 && op <= 5) {
                    return op;
                }
            } else {
                scanner.next();
            }
            System.out.println("Opción inválida.");
        }
    }
    
    private static List<String> cargarEstrategia() throws IOException {
        Path ruta = Paths.get(ARCHIVO_ESTRATEGIA);
        if (!Files.exists(ruta)) {
            return null;
        }
        List<String> validos = new ArrayList<>();
        for (String linea : Files.readAllLines(ruta, StandardCharsets.UTF_8)) {
            String mov = linea.trim().toUpperCase();
            if (mov.isEmpty()) {
                continue;
            }
            if (Arrays.asList(MOVIMIENTOS).contains(mov)) {
                validos.add(mov);
            } else {
                System.out.println("Movimiento ignorado en estrategia.txt: " + linea);
            }
        }
        return validos.isEmpty() ? null : validos;
    }

    
    private static String elegirMovimiento() throws IOException {
        if (estrategia != null) {
            String mov = estrategia.get(indiceEstrategia % estrategia.size());
            indiceEstrategia++;
            System.out.println("Estrategia automática: " + mov);
            return mov;
        }

        String mov = MOVIMIENTOS[leerMovimiento() - 1];
        if (grabarEstrategia) {
            Files.write(Paths.get(ARCHIVO_ESTRATEGIA),
                    (mov + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        }
        return mov;
    }
}
