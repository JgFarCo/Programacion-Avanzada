package com.mechadeluel.mechaduel.modelo;

public class MechaRival extends Robot {

    public MechaRival(int atk, int def, int spd, int nrg, String efectosEstado) {
        super(atk, def, spd, nrg, efectosEstado, true);

    }

    @Override
    public String ejecutarHabilidadEspecial() {
        return "Mecha rival (stats recibidas por red)";
    }
    @Override
    public void pasiva(Robot rival) {
        if(this.efectosEstado.equals("Quemadura")) {
            rival.setHp(rival.getHp()-3);
        }else if(this.efectosEstado.equals("Regeneracion")){
            this.hp+=3;
        }else{
            this.nrg += 2;
        }
    }
}
