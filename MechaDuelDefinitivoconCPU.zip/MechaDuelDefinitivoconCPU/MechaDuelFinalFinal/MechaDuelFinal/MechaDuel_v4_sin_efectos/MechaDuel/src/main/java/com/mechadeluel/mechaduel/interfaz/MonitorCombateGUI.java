package com.mechadeluel.mechaduel.interfaz;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MonitorCombateGUI extends Application {

    private static volatile MonitorCombateGUI instancia;
    private static final CountDownLatch listo = new CountDownLatch(1);
    private ListView<String> listaMisMovimientos;
    private ListView<String> listaMovimientosRival;

    public static MonitorCombateGUI getInstancia() {
        return instancia;
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Mecha Duel - Movimientos Historial");

        Label lblMios = new Label("Movimientos de tu mecha");
        lblMios.setStyle("-fx-font-weight: bold;");
        listaMisMovimientos = new ListView<>();

        Label lblRival = new Label("Movimientos del rival");
        lblRival.setStyle("-fx-font-weight: bold;");
        listaMovimientosRival = new ListView<>();

        VBox colMios = new VBox(8, lblMios, listaMisMovimientos);
        VBox colRival = new VBox(8, lblRival, listaMovimientosRival);

        HBox columnas = new HBox(15, colMios, colRival);
        columnas.setPadding(new Insets(15));

        Scene scene = new Scene(columnas, 520, 360);
        primaryStage.setScene(scene);
        primaryStage.show();

        instancia = this;      
        listo.countDown();
    }

    
    public static void esperarListo() throws InterruptedException {
        listo.await(5, TimeUnit.SECONDS);
    }

    public void registrarMovimientoPropio(String movimiento) {
        Platform.runLater(() -> {
            if(listaMisMovimientos != null) {
                listaMisMovimientos.getItems().add(movimiento);
            }
        });
    }

    public void registrarMovimientoRival(String movimiento) {
        Platform.runLater(() -> {
            if(listaMovimientosRival != null) {
                listaMovimientosRival.getItems().add(movimiento);
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
