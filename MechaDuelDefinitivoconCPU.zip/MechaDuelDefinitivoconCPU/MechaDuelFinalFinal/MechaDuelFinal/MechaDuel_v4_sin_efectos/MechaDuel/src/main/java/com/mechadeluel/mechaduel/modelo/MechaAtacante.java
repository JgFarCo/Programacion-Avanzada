package com.mechadeluel.mechaduel.modelo;

public class MechaAtacante extends Robot {

    public MechaAtacante(int atk, int def, int spd, int nrg, String efectosEstado) {

        super(atk, def, spd, nrg, efectosEstado);

    }

    @Override
    public String ejecutarHabilidadEspecial() {
        this.atk += 5;
        return "¡Arquetipo atacante activado! El ataque ha aumentado";
    }
    @Override
    public void pasiva(Robot rival) {
        rival.setHp(rival.getHp()-3);
    }
}
